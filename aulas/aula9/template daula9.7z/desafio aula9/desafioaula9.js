function clicar(){
 var divResultado = document.getElementById('valorD')
 var html = "O valor em libra é: " + divResultado * 0.72 

 divResultado.innerHTML = html
}